# Open Day

## Summary

Planning an Open Day.

### More Information
A basic example.
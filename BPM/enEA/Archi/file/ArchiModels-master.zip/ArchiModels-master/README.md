# ArchiMate® Example Models

### Notice

This repository is no longer maintained and has been archived. The models here are outdated.

Instead, please check out the [ArchiMate User Community](https://community.opengroup.org/archimate-user-community).

### Links

[Archi Website](https://www.archimatetool.com)  
[The Open Group ArchiMate Exchange File Format](https://www.opengroup.org/open-group-archimate-model-exchange-file-format)  

#### Notes
ArchiMate® is an open and independent Enterprise Architecture modelling language that supports the description, analysis and visualisation of architecture within and across business domains. ArchiMate® is a registered trademark of The Open Group.

Archi® is an ArchiMate modelling tool targeted toward all levels of Enterprise Architects. It provides a low cost to entry solution to users who are looking for a free, cross-platform ArchiMate modelling tool for their company or institution. Archi® is a registered trademark of Phillip Beauvoir.
